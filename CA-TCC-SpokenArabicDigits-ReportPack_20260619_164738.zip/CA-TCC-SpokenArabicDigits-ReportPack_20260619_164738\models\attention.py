"""Transformer context encoder used by TS-TCC temporal contrasting.

This module follows the structure of the authors' public implementation.
"""

import torch
from torch import nn


class Residual(nn.Module):
    def __init__(self, fn):
        super().__init__()
        self.fn = fn

    def forward(self, x, **kwargs):
        return self.fn(x, **kwargs) + x


class PreNorm(nn.Module):
    def __init__(self, dim, fn):
        super().__init__()
        self.norm = nn.LayerNorm(dim)
        self.fn = fn

    def forward(self, x, **kwargs):
        return self.fn(self.norm(x), **kwargs)


class FeedForward(nn.Module):
    def __init__(self, dim, hidden_dim, dropout=0.0):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(dim, hidden_dim),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, dim),
            nn.Dropout(dropout),
        )

    def forward(self, x):
        return self.net(x)


class Attention(nn.Module):
    def __init__(self, dim, heads=8, dropout=0.0):
        super().__init__()
        if dim % heads != 0:
            raise ValueError(f'dim={dim} must be divisible by heads={heads}')
        self.heads = heads
        self.head_dim = dim // heads
        self.scale = dim ** -0.5
        self.to_qkv = nn.Linear(dim, dim * 3, bias=False)
        self.to_out = nn.Sequential(nn.Linear(dim, dim), nn.Dropout(dropout))

    def forward(self, x, mask=None):
        batch, length, dim = x.shape
        qkv = self.to_qkv(x).chunk(3, dim=-1)
        q, k, v = [
            tensor.reshape(batch, length, self.heads, self.head_dim).transpose(1, 2)
            for tensor in qkv
        ]
        scores = torch.matmul(q, k.transpose(-1, -2)) * self.scale
        if mask is not None:
            if mask.ndim != 2 or mask.shape != (batch, length):
                raise ValueError('mask must have shape [batch, sequence_length]')
            pair_mask = mask[:, None, :, None] & mask[:, None, None, :]
            scores = scores.masked_fill(~pair_mask, float('-inf'))
        attention = scores.softmax(dim=-1)
        out = torch.matmul(attention, v)
        out = out.transpose(1, 2).reshape(batch, length, dim)
        return self.to_out(out)


class Transformer(nn.Module):
    def __init__(self, dim, depth, heads, mlp_dim, dropout):
        super().__init__()
        self.layers = nn.ModuleList([
            nn.ModuleList([
                Residual(PreNorm(dim, Attention(dim, heads=heads, dropout=dropout))),
                Residual(PreNorm(dim, FeedForward(dim, mlp_dim, dropout=dropout))),
            ])
            for _ in range(depth)
        ])

    def forward(self, x, mask=None):
        for attention, feed_forward in self.layers:
            x = attention(x, mask=mask)
            x = feed_forward(x)
        return x


class Seq_Transformer(nn.Module):
    def __init__(self, *, patch_size, dim, depth, heads, mlp_dim, channels=1, dropout=0.1):
        super().__init__()
        self.patch_to_embedding = nn.Linear(channels * patch_size, dim)
        self.c_token = nn.Parameter(torch.randn(1, 1, dim))
        self.transformer = Transformer(dim, depth, heads, mlp_dim, dropout)

    def forward(self, forward_seq):
        x = self.patch_to_embedding(forward_seq)
        context_tokens = self.c_token.expand(x.shape[0], -1, -1)
        x = torch.cat((context_tokens, x), dim=1)
        x = self.transformer(x)
        return x[:, 0]
