"""Augmentations for CA-TCC.

The legacy scaling/jitter/permutation functions are retained for compatibility.
For MFCC speech, a semantics-preserving branch avoids segment permutation.
"""

import numpy as np
import torch


def DataTransform(sample, config):
    aug = config.augmentation
    if getattr(aug, 'name', 'legacy') == 'speech_mfcc':
        return speech_weak(sample, aug), speech_strong(sample, aug)
    weak = scaling(sample, sigma=aug.jitter_scale_ratio)
    strong = jitter(permutation(sample, max_segments=aug.max_seg), aug.jitter_ratio)
    return weak, strong


def _channel_scaling(x, sigma):
    factors = 1.0 + torch.randn(
        x.shape[0], x.shape[1], 1, device=x.device, dtype=x.dtype
    ) * sigma
    return x * factors


def _jitter(x, sigma):
    return x + torch.randn_like(x) * sigma


def _time_shift(x, max_ratio):
    output = torch.zeros_like(x)
    max_shift = max(1, int(round(x.shape[2] * max_ratio)))
    shifts = torch.randint(-max_shift, max_shift + 1, (x.shape[0],), device=x.device)
    for idx, shift_tensor in enumerate(shifts):
        shift = int(shift_tensor.item())
        if shift == 0:
            output[idx] = x[idx]
        elif shift > 0:
            output[idx, :, shift:] = x[idx, :, :-shift]
        else:
            amount = -shift
            output[idx, :, :-amount] = x[idx, :, amount:]
    return output


def _time_mask(x, max_ratio):
    output = x.clone()
    max_width = max(1, int(round(x.shape[2] * max_ratio)))
    for idx in range(x.shape[0]):
        width = int(torch.randint(0, max_width + 1, (1,), device=x.device).item())
        if width:
            start = int(torch.randint(0, x.shape[2] - width + 1, (1,), device=x.device).item())
            output[idx, :, start:start + width] = 0.0
    return output


def _channel_mask(x, max_channels):
    output = x.clone()
    max_channels = min(max_channels, x.shape[1])
    for idx in range(x.shape[0]):
        count = int(torch.randint(0, max_channels + 1, (1,), device=x.device).item())
        if count:
            channels = torch.randperm(x.shape[1], device=x.device)[:count]
            output[idx, channels, :] = 0.0
    return output


def speech_weak(x, cfg):
    output = x.detach().clone().float()
    return _jitter(_channel_scaling(output, cfg.weak_scale_sigma), cfg.weak_jitter_sigma)


def speech_strong(x, cfg):
    output = x.detach().clone().float()
    output = _channel_scaling(output, cfg.strong_scale_sigma)
    output = _jitter(output, cfg.strong_jitter_sigma)
    output = _time_shift(output, cfg.max_time_shift_ratio)
    output = _time_mask(output, cfg.max_time_mask_ratio)
    return _channel_mask(output, cfg.max_channel_masks)


# Legacy functions from the public implementation, kept for reference/compatibility.
def jitter(x, sigma=0.8):
    if isinstance(x, torch.Tensor):
        return x + torch.as_tensor(
            np.random.normal(0.0, sigma, size=tuple(x.shape)), dtype=x.dtype, device=x.device
        )
    return x + np.random.normal(0.0, sigma, size=x.shape)


def scaling(x, sigma=1.1):
    tensor = x.detach().cpu().numpy() if isinstance(x, torch.Tensor) else np.asarray(x)
    factor = np.random.normal(2.0, sigma, size=(tensor.shape[0], tensor.shape[2]))
    augmented = [tensor[:, i, :] * factor for i in range(tensor.shape[1])]
    result = np.stack(augmented, axis=1)
    return torch.from_numpy(result).to(dtype=x.dtype) if isinstance(x, torch.Tensor) else result


def permutation(x, max_segments=5, seg_mode='random'):
    tensor = x.detach().cpu().numpy() if isinstance(x, torch.Tensor) else np.asarray(x)
    original_steps = np.arange(tensor.shape[2])
    segment_counts = np.random.randint(1, max_segments, size=tensor.shape[0])
    output = np.zeros_like(tensor)
    for idx, pattern in enumerate(tensor):
        if segment_counts[idx] > 1:
            if seg_mode == 'random':
                points = np.random.choice(tensor.shape[2] - 2, segment_counts[idx] - 1, replace=False)
                points.sort()
                splits = np.split(original_steps, points)
            else:
                splits = np.array_split(original_steps, segment_counts[idx])
            warp = np.concatenate(np.random.permutation(splits)).ravel()
            output[idx] = pattern[:, warp]
        else:
            output[idx] = pattern
    return torch.from_numpy(output).to(dtype=x.dtype) if isinstance(x, torch.Tensor) else output
