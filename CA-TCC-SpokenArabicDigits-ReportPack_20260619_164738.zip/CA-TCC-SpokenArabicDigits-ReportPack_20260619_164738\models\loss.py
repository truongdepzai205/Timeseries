"""Contextual and supervised contrastive losses used in TS-TCC/CA-TCC."""

import torch
from torch import nn
import torch.nn.functional as F


class NTXentLoss(nn.Module):
    """Dynamic-batch NT-Xent loss; equivalent objective to the authors' code."""

    def __init__(self, device, batch_size=None, temperature=0.2, use_cosine_similarity=True):
        super().__init__()
        self.device = device
        self.temperature = temperature
        self.use_cosine_similarity = use_cosine_similarity

    def forward(self, zis, zjs):
        batch = zis.shape[0]
        representations = torch.cat([zjs, zis], dim=0)
        if self.use_cosine_similarity:
            representations = F.normalize(representations, dim=1)
        similarity = torch.matmul(representations, representations.T)

        eye = torch.eye(2 * batch, dtype=torch.bool, device=similarity.device)
        positives = torch.cat([
            torch.diagonal(similarity, offset=batch),
            torch.diagonal(similarity, offset=-batch),
        ]).unsqueeze(1)

        positive_mask = torch.zeros_like(eye)
        ids = torch.arange(batch, device=similarity.device)
        positive_mask[ids, ids + batch] = True
        positive_mask[ids + batch, ids] = True
        negative_mask = ~(eye | positive_mask)
        negatives = similarity[negative_mask].view(2 * batch, -1)

        logits = torch.cat([positives, negatives], dim=1) / self.temperature
        labels = torch.zeros(2 * batch, dtype=torch.long, device=similarity.device)
        return F.cross_entropy(logits, labels)


class SupConLoss(nn.Module):
    """Supervised Contrastive Learning loss (Khosla et al., 2020)."""

    def __init__(self, device, temperature=0.2, contrast_mode='all', base_temperature=0.2):
        super().__init__()
        self.device = device
        self.temperature = temperature
        self.contrast_mode = contrast_mode
        self.base_temperature = base_temperature

    def forward(self, features, labels=None, mask=None):
        if features.ndim < 3:
            raise ValueError('features must have shape [batch, views, ...]')
        if features.ndim > 3:
            features = features.view(features.shape[0], features.shape[1], -1)

        batch_size = features.shape[0]
        if labels is not None and mask is not None:
            raise ValueError('Use either labels or mask, not both.')
        if labels is None and mask is None:
            mask = torch.eye(batch_size, device=features.device)
        elif labels is not None:
            labels = labels.contiguous().view(-1, 1)
            if labels.shape[0] != batch_size:
                raise ValueError('labels length does not match batch size')
            mask = torch.eq(labels, labels.T).float().to(features.device)
        else:
            mask = mask.float().to(features.device)

        contrast_count = features.shape[1]
        contrast_feature = torch.cat(torch.unbind(features, dim=1), dim=0)
        if self.contrast_mode == 'one':
            anchor_feature = features[:, 0]
            anchor_count = 1
        elif self.contrast_mode == 'all':
            anchor_feature = contrast_feature
            anchor_count = contrast_count
        else:
            raise ValueError(f'Unknown contrast_mode={self.contrast_mode}')

        logits = torch.matmul(anchor_feature, contrast_feature.T) / self.temperature
        logits = logits - logits.max(dim=1, keepdim=True).values.detach()
        mask = mask.repeat(anchor_count, contrast_count)
        logits_mask = torch.ones_like(mask)
        diagonal = torch.arange(batch_size * anchor_count, device=features.device).view(-1, 1)
        logits_mask.scatter_(1, diagonal, 0)
        mask = mask * logits_mask

        exp_logits = torch.exp(logits) * logits_mask
        log_prob = logits - torch.log(exp_logits.sum(dim=1, keepdim=True).clamp_min(1e-12))
        positive_count = mask.sum(dim=1).clamp_min(1.0)
        mean_log_prob_pos = (mask * log_prob).sum(dim=1) / positive_count
        loss = -(self.temperature / self.base_temperature) * mean_log_prob_pos
        return loss.view(anchor_count, batch_size).mean()
