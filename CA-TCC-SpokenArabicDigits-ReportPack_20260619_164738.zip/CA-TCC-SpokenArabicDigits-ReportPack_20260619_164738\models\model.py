"""CNN encoder from the public CA-TCC repository, reformatted and documented."""

from torch import nn


class base_Model(nn.Module):
    """Three-block 1D CNN encoder and linear classifier used by TS-TCC/CA-TCC."""

    def __init__(self, configs):
        super().__init__()
        self.conv_block1 = nn.Sequential(
            nn.Conv1d(
                configs.input_channels,
                32,
                kernel_size=configs.kernel_size,
                stride=configs.stride,
                bias=False,
                padding=configs.kernel_size // 2,
            ),
            nn.BatchNorm1d(32),
            nn.ReLU(),
            nn.MaxPool1d(kernel_size=2, stride=2, padding=1),
            nn.Dropout(configs.dropout),
        )
        self.conv_block2 = nn.Sequential(
            nn.Conv1d(32, 64, kernel_size=8, stride=1, bias=False, padding=4),
            nn.BatchNorm1d(64),
            nn.ReLU(),
            nn.MaxPool1d(kernel_size=2, stride=2, padding=1),
        )
        self.conv_block3 = nn.Sequential(
            nn.Conv1d(
                64,
                configs.final_out_channels,
                kernel_size=8,
                stride=1,
                bias=False,
                padding=4,
            ),
            nn.BatchNorm1d(configs.final_out_channels),
            nn.ReLU(),
            nn.MaxPool1d(kernel_size=2, stride=2, padding=1),
        )
        self.logits = nn.Linear(
            configs.features_len * configs.final_out_channels,
            configs.num_classes,
        )

    def forward(self, x_in):
        x = self.conv_block1(x_in)
        x = self.conv_block2(x)
        features = self.conv_block3(x)
        logits = self.logits(features.reshape(features.shape[0], -1))
        return logits, features
