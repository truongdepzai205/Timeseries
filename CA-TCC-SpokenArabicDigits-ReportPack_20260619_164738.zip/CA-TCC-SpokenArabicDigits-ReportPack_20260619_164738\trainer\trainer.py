"""Training routines adapted from the public CA-TCC trainer.

The original objectives are preserved:
- TS-TCC: bidirectional temporal contrasting + NT-Xent contextual loss.
- CA-TCC: temporal regularization + supervised contrastive loss on pseudo labels.
Additional supervised/pseudo-label ablations are included for coursework analysis.
"""

from pathlib import Path
import json
import time
import numpy as np
import pandas as pd
import torch
from torch import nn
import torch.nn.functional as F
from sklearn.metrics import f1_score

from models.loss import NTXentLoss, SupConLoss
from utils import save_checkpoint


def evaluate_classifier(model, loader, device):
    model.eval()
    criterion = nn.CrossEntropyLoss()
    losses, predictions, targets, probabilities = [], [], [], []
    with torch.no_grad():
        for data, labels, _, _ in loader:
            data, labels = data.float().to(device), labels.long().to(device)
            logits, _ = model(data)
            losses.append(criterion(logits, labels).item())
            probs = logits.softmax(dim=1)
            predictions.extend(logits.argmax(dim=1).cpu().tolist())
            targets.extend(labels.cpu().tolist())
            probabilities.extend(probs.cpu().tolist())
    accuracy = float(np.mean(np.asarray(predictions) == np.asarray(targets)))
    macro_f1 = float(f1_score(targets, predictions, average='macro', zero_division=0))
    return {
        'loss': float(np.mean(losses)) if losses else 0.0,
        'accuracy': accuracy,
        'macro_f1': macro_f1,
        'predictions': predictions,
        'targets': targets,
        'probabilities': probabilities,
    }


def _supervised_epoch(model, loader, optimizer, device):
    model.train()
    criterion = nn.CrossEntropyLoss()
    losses, correct, count = [], 0, 0
    for data, labels, _, _ in loader:
        data, labels = data.float().to(device), labels.long().to(device)
        optimizer.zero_grad(set_to_none=True)
        logits, _ = model(data)
        loss = criterion(logits, labels)
        loss.backward()
        optimizer.step()
        losses.append(loss.item())
        correct += int((logits.argmax(dim=1) == labels).sum().item())
        count += len(labels)
    return float(np.mean(losses)), correct / max(count, 1)


def fit_supervised(model, temporal_model, train_loader, val_loader, optimizer, device, config, output_dir, logger, epochs=None):
    output_dir = Path(output_dir)
    epochs = epochs or config.num_epoch
    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(optimizer, mode='min', patience=3)
    history, best_f1, patience = [], -1.0, 0
    for epoch in range(1, epochs + 1):
        started = time.time()
        train_loss, train_acc = _supervised_epoch(model, train_loader, optimizer, device)
        val = evaluate_classifier(model, val_loader, device)
        scheduler.step(val['loss'])
        row = {
            'epoch': epoch,
            'train_loss': train_loss,
            'train_accuracy': train_acc,
            'val_loss': val['loss'],
            'val_accuracy': val['accuracy'],
            'val_macro_f1': val['macro_f1'],
            'seconds': time.time() - started,
        }
        history.append(row)
        logger.info(
            f"Epoch {epoch:03d} | train loss {train_loss:.4f} acc {train_acc:.4f} | "
            f"val loss {val['loss']:.4f} acc {val['accuracy']:.4f} macro-F1 {val['macro_f1']:.4f}"
        )
        save_checkpoint(output_dir / 'saved_models/ckp_last.pt', model, temporal_model, epoch, {'history': history})
        if val['macro_f1'] > best_f1:
            best_f1, patience = val['macro_f1'], 0
            save_checkpoint(output_dir / 'saved_models/ckp_best.pt', model, temporal_model, epoch, {'history': history})
        else:
            patience += 1
            if patience >= config.early_stopping_patience:
                logger.info(f'Early stopping at epoch {epoch}.')
                break
    pd.DataFrame(history).to_csv(output_dir / 'history.csv', index=False)
    return history


def _contrastive_epoch(model, temporal_model, loader, model_optimizer, temporal_optimizer, device, config, mode):
    model.train(); temporal_model.train()
    losses = []
    ntxent = NTXentLoss(device, temperature=config.Context_Cont.temperature,
                        use_cosine_similarity=config.Context_Cont.use_cosine_similarity)
    supcon = SupConLoss(device, temperature=config.Context_Cont.temperature)
    for _, labels, aug1, aug2 in loader:
        labels = labels.long().to(device)
        aug1, aug2 = aug1.float().to(device), aug2.float().to(device)
        model_optimizer.zero_grad(set_to_none=True)
        temporal_optimizer.zero_grad(set_to_none=True)
        _, features1 = model(aug1)
        _, features2 = model(aug2)
        features1 = F.normalize(features1, dim=1)
        features2 = F.normalize(features2, dim=1)
        temporal_loss1, context1 = temporal_model(features1, features2)
        temporal_loss2, context2 = temporal_model(features2, features1)
        if mode == 'self_supervised':
            loss = (
                (temporal_loss1 + temporal_loss2) * config.ssl_temporal_weight
                + ntxent(context1, context2) * config.ssl_contextual_weight
            )
        elif mode.startswith('SupCon'):
            views = torch.stack([context1, context2], dim=1)
            loss = (
                (temporal_loss1 + temporal_loss2) * config.supcon_temporal_weight
                + supcon(views, labels) * config.supcon_weight
            )
        else:
            raise ValueError(f'Unknown contrastive mode: {mode}')
        loss.backward()
        model_optimizer.step(); temporal_optimizer.step()
        losses.append(loss.item())
    return float(np.mean(losses))


def fit_contrastive(model, temporal_model, train_loader, model_optimizer, temporal_optimizer, device, config, output_dir, logger, mode, epochs=None):
    output_dir = Path(output_dir)
    epochs = epochs or config.num_epoch
    history, best_loss = [], float('inf')
    for epoch in range(1, epochs + 1):
        started = time.time()
        train_loss = _contrastive_epoch(
            model, temporal_model, train_loader, model_optimizer, temporal_optimizer,
            device, config, mode,
        )
        row = {'epoch': epoch, 'train_loss': train_loss, 'seconds': time.time() - started}
        history.append(row)
        logger.info(f'Epoch {epoch:03d} | {mode} loss {train_loss:.4f}')
        save_checkpoint(output_dir / 'saved_models/ckp_last.pt', model, temporal_model, epoch, {'history': history})
        if train_loss < best_loss:
            best_loss = train_loss
            save_checkpoint(output_dir / 'saved_models/ckp_best.pt', model, temporal_model, epoch, {'history': history})
    pd.DataFrame(history).to_csv(output_dir / 'history.csv', index=False)
    return history


def generate_pseudo_labels(model, full_dataset_payload, labeled_payload, device, output_path, confidence_threshold=0.0, batch_size=256):
    """Predict labels for full train data and restore human labels at known indices."""
    samples = torch.as_tensor(full_dataset_payload['samples']).float()
    true_labels_audit = torch.as_tensor(full_dataset_payload['labels']).long()
    source_indices = torch.as_tensor(
        full_dataset_payload.get('source_indices', torch.arange(len(samples))), dtype=torch.long
    )
    known_indices = torch.as_tensor(labeled_payload.get('source_indices', []), dtype=torch.long)
    known_labels = torch.as_tensor(labeled_payload['labels']).long()
    known_map = {int(index): int(label) for index, label in zip(known_indices.tolist(), known_labels.tolist())}

    model.eval(); all_pred, all_conf = [], []
    with torch.no_grad():
        for start in range(0, len(samples), batch_size):
            logits, _ = model(samples[start:start + batch_size].to(device))
            probs = logits.softmax(dim=1)
            conf, pred = probs.max(dim=1)
            all_pred.append(pred.cpu()); all_conf.append(conf.cpu())
    pseudo = torch.cat(all_pred)
    confidence = torch.cat(all_conf)
    is_human = torch.zeros(len(samples), dtype=torch.bool)
    for row_idx, source_idx in enumerate(source_indices.tolist()):
        if source_idx in known_map:
            pseudo[row_idx] = known_map[source_idx]
            confidence[row_idx] = 1.0
            is_human[row_idx] = True
    keep = is_human | (confidence >= confidence_threshold)
    payload = {
        'samples': samples[keep].contiguous(),
        'labels': pseudo[keep].contiguous(),
        'source_indices': source_indices[keep].contiguous(),
        'confidence': confidence[keep].contiguous(),
        'is_human_label': is_human[keep].contiguous(),
    }
    output_path = Path(output_path); output_path.parent.mkdir(parents=True, exist_ok=True)
    torch.save(payload, output_path)

    audit_pred = pseudo.numpy(); audit_true = true_labels_audit.numpy()
    audit = {
        'n_total': int(len(samples)),
        'n_kept': int(keep.sum()),
        'acceptance_rate': float(keep.float().mean()),
        'mean_confidence': float(confidence.mean()),
        'pseudo_accuracy_all_for_audit_only': float((pseudo == true_labels_audit).float().mean()),
        'pseudo_accuracy_unknown_for_audit_only': float(
            (pseudo[~is_human] == true_labels_audit[~is_human]).float().mean()
        ) if (~is_human).any() else None,
        'n_human_labels': int(is_human.sum()),
        'confidence_threshold': float(confidence_threshold),
    }
    output_path.with_suffix('.json').write_text(json.dumps(audit, indent=2), encoding='utf-8')
    pd.DataFrame({
        'source_index': source_indices.numpy(),
        'true_label_audit_only': audit_true,
        'pseudo_label': audit_pred,
        'confidence': confidence.numpy(),
        'is_human_label': is_human.numpy(),
        'kept': keep.numpy(),
    }).to_csv(output_path.with_name(output_path.stem + '_audit.csv'), index=False)
    return audit
