# Context for ChatGPT report writing

File này tóm tắt nhanh dữ liệu, EDA, tiền xử lý và vị trí hình ảnh để ChatGPT có thể đọc trực tiếp khi viết báo cáo.

## 1. Dataset

- Dataset: Spoken Arabic Digits.
- Nguồn: UCI Machine Learning Repository, `spoken+arabic+digit.zip`.
- Bài toán: phân loại chữ số tiếng Ả Rập được nói ra, nhãn từ 0 đến 9.
- Dạng dữ liệu gốc: mỗi mẫu là một chuỗi thời gian âm thanh đã trích xuất MFCC.
- Mỗi frame có 13 hệ số MFCC, tức 13 kênh đặc trưng.
- Độ dài chuỗi gốc không cố định, dao động từ 4 đến 93 frame.
- Sau tiền xử lý, mỗi mẫu có shape `[13, 96]`.
- Shape dùng cho CA-TCC: `[N, C, T] = [N, 13, 96]`.

## 2. Metadata columns

File chính để hiểu cấu trúc dữ liệu:

```text
data/SpokenArabicDigits/split_metadata.csv
```

File này có 8.800 dòng và 11 cột:

```text
source_split, source_index, label, digit, gender, speaker_local,
speaker_id, repetition, length, n_features, split
```

Ý nghĩa:

- `source_split`: nguồn gốc theo split UCI ban đầu (`uci_train`, `uci_test`).
- `source_index`: chỉ số mẫu trong nguồn ban đầu.
- `label`: nhãn số từ 0 đến 9.
- `digit`: chữ số được đọc, tương ứng với label.
- `gender`: giới tính người nói.
- `speaker_local`: mã người nói cục bộ.
- `speaker_id`: định danh người nói sau khi chuẩn hóa.
- `repetition`: lần lặp phát âm chữ số.
- `length`: số frame trước khi nội suy.
- `n_features`: số đặc trưng MFCC, luôn là 13.
- `split`: split sau tiền xử lý (`train`, `val`, `test`).

## 3. Missing values and data quality

Theo notebook EDA:

- Không có thiếu dữ liệu trong metadata đã lưu.
- Kiểm tra chất lượng gồm: NaN, vô cực, số đặc trưng, độ dài nhỏ nhất/lớn nhất, block trùng hoàn toàn, cân bằng lớp, số lần lặp theo người nói và chữ số.
- `n_features = 13` cho toàn bộ mẫu.
- Độ dài chuỗi gốc: min 4, median 39, mean 39.81, max 93 frame.

## 4. Train/validation/test split

Tổng số mẫu: 8.800.

```text
train: 5.500
val:   1.100
test:  2.200
```

Phân bố lớp cân bằng:

```text
train: mỗi lớp 550 mẫu
val:   mỗi lớp 110 mẫu
test:  mỗi lớp 220 mẫu
```

Phân bố giới tính:

```text
train: female 2800, male 2700
val:   female 500,  male 600
test:  female 1100, male 1100
```

Chia validation được thực hiện theo người nói. Tập test chính thức của UCI đã dùng người nói khác với tập train.

## 5. Preprocessing pipeline

Notebook chính:

```text
notebooks/01_EDA_Preprocessing_SpokenArabicDigits.ipynb
```

Các bước tiền xử lý:

1. Tải dữ liệu chính thức từ UCI.
2. Đọc dữ liệu theo block: mỗi block là một câu nói, các dòng trong block là frame MFCC.
3. Tạo nhãn chữ số 0-9 và metadata người nói.
4. Kiểm tra dữ liệu thiếu, NaN, vô cực, số chiều đặc trưng và độ dài chuỗi.
5. Tách train/validation theo người nói; giữ test chính thức.
6. Tính mean/std của từng MFCC chỉ từ frame thuộc train.
7. Chuẩn hóa train, validation và test bằng thống kê train.
8. Nội suy tuyến tính mỗi chuỗi về 96 frame.
9. Chuyển tensor từ `[N, T, C]` sang `[N, C, T]`.
10. Lưu dữ liệu theo định dạng CA-TCC: `samples`, `labels`, và `source_indices` cho tập ít nhãn.

Nội suy tuyến tính được dùng thay zero-padding vì encoder và augmentation gốc không hỗ trợ padding mask.

## 6. Low-label splits

Các tỷ lệ ít nhãn đã tạo cho thí nghiệm:

```text
1%:  60 mẫu,  mỗi lớp 6 mẫu
5%:  280 mẫu, mỗi lớp 28 mẫu
10%: 550 mẫu, mỗi lớp 55 mẫu
50%: 2750 mẫu
75%: 4120 mẫu
```

Các tỷ lệ chính trong báo cáo thường dùng: 1%, 5%, 10%.

## 7. Visual assets for direct citation

Các hình EDA đã được xuất ra file PNG riêng tại:

```text
report_assets/eda_figures/
```

Danh sách hình:

```text
report_assets/eda_figures/figure_index.csv
```

Các nhóm hình quan trọng:

- `cell_15_figure_*.png`: phân tích độ dài chuỗi.
- `cell_17_figure_*.png`: phân tích phân bố các hệ số MFCC.
- `cell_19_figure_*.png`: trực quan một số chuỗi MFCC theo chữ số.
- `cell_21_figure_01.png`: PCA thăm dò trên đặc trưng thống kê.
- `cell_29_figure_*.png`: so sánh trước/sau nội suy để kiểm tra biến dạng.

Những hình này có thể chèn trực tiếp vào báo cáo hoặc dùng làm bằng chứng trực quan khi mô tả EDA.

## 8. Result files

Kết quả tổng hợp nằm ở:

```text
results/
```

Các file quan trọng:

```text
results/summary_by_method_and_ratio.csv
results/macro_f1_pivot.csv
results/macro_f1_stability.csv
results/ca_tcc_vs_ts_tcc.csv
results/pseudo_label_audit_summary.csv
results/macro_f1_comparison.png
```

Log và metrics chi tiết đã giữ dạng text trong:

```text
experiments_logs/
```

Bản pack đã loại bỏ checkpoint `.pt`, tensor `.npy`, virtual environment và raw dataset để giảm dung lượng. Vì vậy pack này phù hợp để đọc, hiểu, trích dẫn và viết báo cáo; không nhằm mục đích chạy lại toàn bộ pipeline từ dữ liệu thô.
