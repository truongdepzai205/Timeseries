"""Run the complete comparison matrix.

Official comparison:
- supervised: no TS-TCC, no CA stage
- ts_tcc: TS-TCC pretraining + low-label fine-tuning
- ca_tcc: TS-TCC + fine-tuning + pseudo labels + SupCon + linear evaluation

Ablations:
- ts_pl: TS-TCC + pseudo-label cross-entropy, no SupCon
- ts_supcon: TS-TCC + SupCon on human labels only, no pseudo labels
- ca_scratch: CA stages initialized by a low-label supervised model, no TS-TCC pretraining
"""

from pathlib import Path
import argparse
import csv
import os
from datetime import datetime, timezone
import shlex
import subprocess
import sys
import time

PROJECT_ROOT = Path(__file__).resolve().parents[1]
PYTHON = sys.executable


def command_string(args):
    return ' '.join(shlex.quote(str(item)) for item in args)


def _arg_value(args, flag, default=None):
    return args[args.index(flag) + 1] if flag in args else default


def expected_output(args):
    exp = _arg_value(args, '--experiment_description', 'SpokenArabicDigits_matrix')
    run_name = _arg_value(args, '--run_description', 'baseline')
    mode = _arg_value(args, '--training_mode')
    seed = _arg_value(args, '--seed', '0')
    dataset = _arg_value(args, '--selected_dataset', 'SpokenArabicDigits')
    data_root = Path(_arg_value(args, '--data_path', 'data'))
    if not data_root.is_absolute():
        data_root = PROJECT_ROOT / data_root
    label_ratio = _arg_value(args, '--label_percentage')
    logs_root = Path(_arg_value(args, '--logs_save_dir', 'experiments_logs'))
    if not logs_root.is_absolute():
        logs_root = PROJECT_ROOT / logs_root
    output_dir = logs_root / exp / run_name / f'{mode}_seed_{seed}'
    if mode and mode.startswith('gen_pseudo_labels'):
        if label_ratio is None:
            import re
            match = re.search(r'_(1|5|10|50|75)p', mode)
            label_ratio = match.group(1) if match else None
        pseudo_name = _arg_value(args, '--pseudo_output', f'pseudo_train_{label_ratio}perc.pt')
        return data_root / dataset / pseudo_name
    if mode == 'self_supervised' or (mode and mode.startswith('SupCon')):
        return output_dir / 'saved_models' / 'ckp_last.pt'
    return output_dir / 'metrics.json'


def _append_orchestration_record(args, expected, status, seconds=0.0, error=''):
    logs_root = Path(_arg_value(args, '--logs_save_dir', 'experiments_logs'))
    if not logs_root.is_absolute():
        logs_root = PROJECT_ROOT / logs_root
    experiment = _arg_value(args, '--experiment_description', 'SpokenArabicDigits_matrix')
    path = logs_root / experiment / 'orchestration_log.csv'
    path.parent.mkdir(parents=True, exist_ok=True)
    mode = _arg_value(args, '--training_mode', '')
    label_percentage = _arg_value(args, '--label_percentage', '') or ''
    if not label_percentage and mode:
        import re
        match = re.search(r'_(1|5|10|50|75)p(?:$|_)', mode)
        label_percentage = match.group(1) if match else ''
    row = {
        'timestamp_utc': datetime.now(timezone.utc).isoformat(),
        'run_description': _arg_value(args, '--run_description', ''),
        'method': _arg_value(args, '--method_name', ''),
        'training_mode': mode,
        'label_percentage': label_percentage,
        'seed': _arg_value(args, '--seed', ''),
        'status': status,
        'seconds': round(float(seconds), 6),
        'expected_output': str(expected),
        'command': command_string(args),
        'error': error,
    }
    exists = path.exists()
    with path.open('a', newline='', encoding='utf-8') as handle:
        writer = csv.DictWriter(handle, fieldnames=list(row))
        if not exists:
            writer.writeheader()
        writer.writerow(row)


def run(args, dry_run=False, force=False):
    expected = expected_output(args)
    if expected.exists() and not force:
        print(f'\nSKIP existing: {expected}', flush=True)
        _append_orchestration_record(args, expected, 'skipped_existing')
        return
    print('\n$', command_string(args), flush=True)
    if dry_run:
        _append_orchestration_record(args, expected, 'dry_run')
        return
    started = time.perf_counter()
    child_env = os.environ.copy()
    cpu_threads = str(_arg_value(args, '--cpu_threads', '4'))
    for name in ('OMP_NUM_THREADS', 'MKL_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'NUMEXPR_NUM_THREADS'):
        child_env[name] = cpu_threads
    try:
        subprocess.run(args, cwd=PROJECT_ROOT, check=True, env=child_env)
    except subprocess.CalledProcessError as exc:
        _append_orchestration_record(
            args, expected, 'failed', time.perf_counter() - started, str(exc)
        )
        raise
    _append_orchestration_record(args, expected, 'success', time.perf_counter() - started)


def checkpoint(exp, run_name, mode, seed, best=False, logs='experiments_logs'):
    filename = 'ckp_best.pt' if best else 'ckp_last.pt'
    logs_root = Path(logs)
    if not logs_root.is_absolute():
        logs_root = PROJECT_ROOT / logs_root
    return logs_root / exp / run_name / f'{mode}_seed_{seed}' / 'saved_models' / filename


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--methods', nargs='+', default=['supervised','ts_tcc','ts_pl','ts_supcon','ca_tcc','ca_scratch'])
    parser.add_argument('--label_ratios', nargs='+', type=int, default=[1,5,10])
    parser.add_argument('--seeds', nargs='+', type=int, default=[0])
    parser.add_argument('--experiment', default='SpokenArabicDigits_matrix')
    parser.add_argument('--dataset', default='SpokenArabicDigits')
    parser.add_argument('--device', default='auto')
    parser.add_argument('--cpu_threads', type=int, default=4)
    parser.add_argument('--data_path', default='data')
    parser.add_argument('--logs_save_dir', default='experiments_logs')
    parser.add_argument('--epochs', type=int, default=None)
    parser.add_argument('--confidence_threshold', type=float, default=0.0)
    parser.add_argument('--dry_run', action='store_true')
    parser.add_argument('--force', action='store_true', help='Run again even when output exists')
    args = parser.parse_args()

    base = [PYTHON, 'main.py', '--experiment_description', args.experiment,
            '--selected_dataset', args.dataset, '--device', args.device,
            '--cpu_threads', str(args.cpu_threads),
            '--data_path', args.data_path, '--logs_save_dir', args.logs_save_dir]
    if args.epochs is not None:
        base += ['--epochs', str(args.epochs)]

    needs_ts = any(method in args.methods for method in ['ts_tcc','ts_pl','ts_supcon','ca_tcc'])
    for seed in args.seeds:
        ssl_run = 'shared_ts_pretraining'
        ssl_mode = 'self_supervised'
        ssl_ckpt = checkpoint(args.experiment, ssl_run, ssl_mode, seed, logs=args.logs_save_dir)
        if needs_ts:
            run(base + ['--run_description', ssl_run, '--seed', str(seed),
                        '--training_mode', ssl_mode, '--method_name', 'shared_ts'], args.dry_run, args.force)

        for ratio in args.label_ratios:
            for method in args.methods:
                run_name = method
                suffix = f'{ratio}p'
                pseudo_name = f'pseudo_{method}_{ratio}perc_seed{seed}.pt'
                if method == 'supervised':
                    mode = f'supervised_{suffix}'
                    run(base + ['--run_description', run_name, '--seed', str(seed),
                                '--training_mode', mode, '--method_name', method], args.dry_run, args.force)

                elif method == 'ts_tcc':
                    mode = f'ft_{suffix}'
                    run(base + ['--run_description', run_name, '--seed', str(seed),
                                '--training_mode', mode, '--load_checkpoint', str(ssl_ckpt),
                                '--method_name', method], args.dry_run, args.force)

                elif method == 'ts_pl':
                    ft_mode = f'ft_{suffix}'
                    run(base + ['--run_description', run_name, '--seed', str(seed),
                                '--training_mode', ft_mode, '--load_checkpoint', str(ssl_ckpt),
                                '--method_name', method, '--result_role', 'intermediate'], args.dry_run, args.force)
                    ft_ckpt = checkpoint(args.experiment, run_name, ft_mode, seed, best=True, logs=args.logs_save_dir)
                    gen_mode = f'gen_pseudo_labels_{suffix}'
                    run(base + ['--run_description', run_name, '--seed', str(seed),
                                '--training_mode', gen_mode, '--label_percentage', str(ratio),
                                '--load_checkpoint', str(ft_ckpt),
                                '--pseudo_output', pseudo_name,
                                '--confidence_threshold', str(args.confidence_threshold),
                                '--method_name', method], args.dry_run, args.force)
                    final_mode = f'pseudo_ce_{suffix}'
                    run(base + ['--run_description', run_name, '--seed', str(seed),
                                '--training_mode', final_mode, '--load_checkpoint', str(ft_ckpt),
                                '--train_file', pseudo_name, '--method_name', method], args.dry_run, args.force)

                elif method == 'ts_supcon':
                    sup_mode = f'SupCon_labeled_{suffix}'
                    run(base + ['--run_description', run_name, '--seed', str(seed),
                                '--training_mode', sup_mode, '--load_checkpoint', str(ssl_ckpt),
                                '--method_name', method], args.dry_run, args.force)
                    sup_ckpt = checkpoint(args.experiment, run_name, sup_mode, seed, logs=args.logs_save_dir)
                    final_mode = f'train_linear_SupCon_labeled_{suffix}'
                    run(base + ['--run_description', run_name, '--seed', str(seed),
                                '--training_mode', final_mode, '--load_checkpoint', str(sup_ckpt),
                                '--method_name', method], args.dry_run, args.force)

                elif method == 'ca_tcc':
                    ft_mode = f'ft_{suffix}'
                    run(base + ['--run_description', run_name, '--seed', str(seed),
                                '--training_mode', ft_mode, '--load_checkpoint', str(ssl_ckpt),
                                '--method_name', method, '--result_role', 'intermediate'], args.dry_run, args.force)
                    ft_ckpt = checkpoint(args.experiment, run_name, ft_mode, seed, best=True, logs=args.logs_save_dir)
                    gen_mode = f'gen_pseudo_labels_{suffix}'
                    run(base + ['--run_description', run_name, '--seed', str(seed),
                                '--training_mode', gen_mode, '--label_percentage', str(ratio),
                                '--load_checkpoint', str(ft_ckpt),
                                '--pseudo_output', pseudo_name,
                                '--confidence_threshold', str(args.confidence_threshold),
                                '--method_name', method], args.dry_run, args.force)
                    sup_mode = f'SupCon_pseudo_{suffix}'
                    run(base + ['--run_description', run_name, '--seed', str(seed),
                                '--training_mode', sup_mode, '--load_checkpoint', str(ft_ckpt),
                                '--train_file', pseudo_name, '--method_name', method], args.dry_run, args.force)
                    sup_ckpt = checkpoint(args.experiment, run_name, sup_mode, seed, logs=args.logs_save_dir)
                    final_mode = f'train_linear_SupCon_pseudo_{suffix}'
                    run(base + ['--run_description', run_name, '--seed', str(seed),
                                '--training_mode', final_mode, '--load_checkpoint', str(sup_ckpt),
                                '--method_name', method], args.dry_run, args.force)

                elif method == 'ca_scratch':
                    initial_mode = f'supervised_{suffix}'
                    run(base + ['--run_description', run_name, '--seed', str(seed),
                                '--training_mode', initial_mode, '--method_name', method,
                                '--result_role', 'intermediate'], args.dry_run, args.force)
                    initial_ckpt = checkpoint(args.experiment, run_name, initial_mode, seed, best=True, logs=args.logs_save_dir)
                    gen_mode = f'gen_pseudo_labels_{suffix}'
                    run(base + ['--run_description', run_name, '--seed', str(seed),
                                '--training_mode', gen_mode, '--label_percentage', str(ratio),
                                '--load_checkpoint', str(initial_ckpt),
                                '--pseudo_output', pseudo_name,
                                '--confidence_threshold', str(args.confidence_threshold),
                                '--method_name', method], args.dry_run, args.force)
                    sup_mode = f'SupCon_pseudo_{suffix}'
                    run(base + ['--run_description', run_name, '--seed', str(seed),
                                '--training_mode', sup_mode, '--load_checkpoint', str(initial_ckpt),
                                '--train_file', pseudo_name, '--method_name', method], args.dry_run, args.force)
                    sup_ckpt = checkpoint(args.experiment, run_name, sup_mode, seed, logs=args.logs_save_dir)
                    final_mode = f'train_linear_SupCon_pseudo_{suffix}'
                    run(base + ['--run_description', run_name, '--seed', str(seed),
                                '--training_mode', final_mode, '--load_checkpoint', str(sup_ckpt),
                                '--method_name', method], args.dry_run, args.force)
                else:
                    raise ValueError(f'Unknown method: {method}')


if __name__ == '__main__':
    main()
