"""Configuration adapted from the authors' CA-TCC setup for Spoken Arabic Digits."""


class Config:
    def __init__(self):
        self.input_channels = 13
        self.input_length = 96
        self.kernel_size = 8
        self.stride = 1
        self.final_out_channels = 128
        self.num_classes = 10
        self.dropout = 0.35
        self.features_len = 14

        self.num_epoch = 40
        self.early_stopping_patience = 10
        self.beta1 = 0.9
        self.beta2 = 0.99
        self.lr = 3e-4
        self.weight_decay = 3e-4
        self.drop_last = True
        self.batch_size = 128
        self.num_workers = 0

        # Same objective weights used by the adapted author-based trainer.
        self.ssl_temporal_weight = 1.0
        self.ssl_contextual_weight = 0.7
        self.supcon_temporal_weight = 0.01
        self.supcon_weight = 0.1

        self.Context_Cont = ContextContConfig()
        self.TC = TemporalContrastingConfig()
        self.augmentation = SpeechAugmentationConfig()


class SpeechAugmentationConfig:
    def __init__(self):
        self.name = "speech_mfcc"
        self.weak_jitter_sigma = 0.01
        self.weak_scale_sigma = 0.03
        self.strong_jitter_sigma = 0.04
        self.strong_scale_sigma = 0.08
        self.max_time_mask_ratio = 0.12
        self.max_channel_masks = 2
        self.max_time_shift_ratio = 0.05


class ContextContConfig:
    def __init__(self):
        self.temperature = 0.2
        self.use_cosine_similarity = True


class TemporalContrastingConfig:
    def __init__(self):
        self.hidden_dim = 100
        self.timesteps = 6
