"""Temporal contrasting module from TS-TCC/CA-TCC."""

import torch
from torch import nn

from .attention import Seq_Transformer


class TC(nn.Module):
    def __init__(self, configs, device):
        super().__init__()
        self.num_channels = configs.final_out_channels
        self.timestep = configs.TC.timesteps
        self.device = device
        self.Wk = nn.ModuleList([
            nn.Linear(configs.TC.hidden_dim, self.num_channels)
            for _ in range(self.timestep)
        ])
        self.log_softmax = nn.LogSoftmax(dim=1)
        self.projection_head = nn.Sequential(
            nn.Linear(configs.TC.hidden_dim, configs.final_out_channels // 2),
            nn.BatchNorm1d(configs.final_out_channels // 2),
            nn.ReLU(inplace=True),
            nn.Linear(configs.final_out_channels // 2, configs.final_out_channels // 4),
        )
        self.seq_transformer = Seq_Transformer(
            patch_size=self.num_channels,
            dim=configs.TC.hidden_dim,
            depth=4,
            heads=4,
            mlp_dim=64,
        )

    def forward(self, z_aug1, z_aug2):
        if z_aug1.ndim != 3 or z_aug2.ndim != 3:
            raise ValueError('Temporal contrasting expects [batch, channels, time].')
        seq_len = z_aug1.shape[2]
        if seq_len <= self.timestep:
            raise ValueError(
                f'Feature length {seq_len} must exceed TC.timesteps={self.timestep}.'
            )

        z_aug1 = z_aug1.transpose(1, 2)
        z_aug2 = z_aug2.transpose(1, 2)
        batch = z_aug1.shape[0]
        t_sample = int(torch.randint(0, seq_len - self.timestep, (1,), device=z_aug1.device).item())

        targets = torch.stack(
            [z_aug2[:, t_sample + step, :] for step in range(1, self.timestep + 1)],
            dim=0,
        )
        context = self.seq_transformer(z_aug1[:, : t_sample + 1, :])
        predictions = torch.stack([head(context) for head in self.Wk], dim=0)

        nce = torch.zeros((), device=z_aug1.device)
        for step in range(self.timestep):
            scores = torch.matmul(targets[step], predictions[step].transpose(0, 1))
            nce = nce - torch.diagonal(self.log_softmax(scores)).sum()
        nce = nce / (batch * self.timestep)
        return nce, self.projection_head(context)
