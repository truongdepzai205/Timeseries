Thư mục này được tạo/ghi kết quả bởi:

python experiments/aggregate_results.py --experiment SpokenArabicDigits_matrix --output results

Không sử dụng số liệu từ smoke test làm kết quả báo cáo.
