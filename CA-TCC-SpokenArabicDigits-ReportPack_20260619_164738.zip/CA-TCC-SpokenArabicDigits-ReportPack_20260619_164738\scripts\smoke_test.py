"""Fast shape/loss/data-loader test using synthetic data; no dataset download required."""

from pathlib import Path
import tempfile
import sys

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))
import torch
import torch.nn.functional as F

torch.set_num_threads(1)
try:
    torch.set_num_interop_threads(1)
except RuntimeError:
    pass

from config_files.SpokenArabicDigits_Configs import Config
from dataloader.augmentations import DataTransform
from dataloader.dataloader import data_generator
from models.model import base_Model
from models.TC import TC
from models.loss import NTXentLoss, SupConLoss


def main():
    config = Config(); config.batch_size = 8
    device = torch.device('cpu')
    model = base_Model(config)
    tc = TC(config, device)
    samples = torch.randn(40, config.input_channels, config.input_length)
    labels = torch.arange(40) % config.num_classes
    weak, strong = DataTransform(samples, config)
    logits1, features1 = model(weak[:8])
    logits2, features2 = model(strong[:8])
    assert logits1.shape == (8, 10)
    assert features1.shape == (8, 128, 14)
    temporal1, context1 = tc(F.normalize(features1, dim=1), F.normalize(features2, dim=1))
    temporal2, context2 = tc(F.normalize(features2, dim=1), F.normalize(features1, dim=1))
    ssl = temporal1 + temporal2 + NTXentLoss(device)(context1, context2)
    assert torch.isfinite(ssl)
    ssl.backward()
    assert any(
        parameter.grad is not None and torch.isfinite(parameter.grad).all()
        for parameter in model.parameters()
    )

    # Rebuild the graph and verify the CA-TCC/SupCon branch can backpropagate.
    model.zero_grad(set_to_none=True)
    tc.zero_grad(set_to_none=True)
    _, features1 = model(weak[:8])
    _, features2 = model(strong[:8])
    temporal1, context1 = tc(F.normalize(features1, dim=1), F.normalize(features2, dim=1))
    temporal2, context2 = tc(F.normalize(features2, dim=1), F.normalize(features1, dim=1))
    sup_labels = torch.arange(8) // 2
    sup = (
        (temporal1 + temporal2) * config.supcon_temporal_weight
        + SupConLoss(device)(torch.stack([context1, context2], dim=1), sup_labels)
        * config.supcon_weight
    )
    assert torch.isfinite(sup)
    sup.backward()
    assert any(
        parameter.grad is not None and torch.isfinite(parameter.grad).all()
        for parameter in model.parameters()
    )
    with tempfile.TemporaryDirectory() as temp:
        root = Path(temp)
        payload = {'samples': samples, 'labels': labels, 'source_indices': torch.arange(40)}
        torch.save(payload, root / 'train.pt')
        torch.save(payload, root / 'val.pt')
        torch.save(payload, root / 'test.pt')
        for ratio in [1,5,10,50,75]:
            torch.save({'samples': samples[:10], 'labels': labels[:10], 'source_indices': torch.arange(10)}, root / f'train_{ratio}perc.pt')
        train, val, test = data_generator(root, config, 'self_supervised')
        batch = next(iter(train))
        assert batch[0].shape[1:] == (13, 96)
    print('SMOKE TEST PASSED')
    print('logits:', tuple(logits1.shape), 'features:', tuple(features1.shape))
    print('ssl loss:', float(ssl.detach()), 'supcon loss:', float(sup.detach()))


if __name__ == '__main__':
    main()
