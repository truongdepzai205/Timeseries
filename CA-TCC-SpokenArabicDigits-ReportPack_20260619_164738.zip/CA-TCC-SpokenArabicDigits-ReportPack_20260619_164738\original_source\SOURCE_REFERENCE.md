# Upstream source reference

This project is an adaptation of:

- Repository: `emadeldeen24/CA-TCC`
- Paper: *Self-Supervised Contrastive Representation Learning for Semi-Supervised Time-Series Classification*, IEEE TPAMI 2023.
- TS-TCC paper: *Time-Series Representation Learning via Temporal and Contextual Contrasting*, IJCAI 2021.

Kept from the authors' design:

- three-block Conv1D encoder and linear classifier;
- Transformer context encoder;
- bidirectional temporal prediction objective;
- NT-Xent contextual contrasting;
- pseudo-label generation followed by supervised contrastive learning;
- `.pt` payload format with `samples` and `labels`.

Changes in this coursework version:

- Spoken Arabic Digit MFCC dataset;
- speech-safe augmentations;
- parameterized 1%, 5%, 10% pipelines;
- fixed percentage/checkpoint paths that were hard-coded in upstream `main.py`;
- independent TS-TCC, CA-TCC and ablation runs;
- reproducible metrics, pseudo-label audit and aggregation scripts;
- dynamic batch handling and CPU fallback.

The upstream GitHub page did not show a repository license file in its top-level listing at the time this package was prepared. Preserve author attribution and verify upstream licensing requirements before redistribution beyond coursework/research use.
