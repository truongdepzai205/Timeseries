"""Data loading compatible with the author's .pt format."""

from pathlib import Path
import re
import numpy as np
import torch
from torch.utils.data import DataLoader, Dataset

from .augmentations import DataTransform


def safe_torch_load(path):
    try:
        return torch.load(path, map_location='cpu', weights_only=False)
    except TypeError:
        return torch.load(path, map_location='cpu')


class Load_Dataset(Dataset):
    def __init__(self, dataset, config, training_mode):
        super().__init__()
        self.training_mode = training_mode
        samples = dataset['samples']
        labels = dataset['labels']
        samples = torch.as_tensor(samples).float()
        labels = torch.as_tensor(labels).long()
        if samples.ndim < 3:
            samples = samples.unsqueeze(1)
        if samples.shape[1] != config.input_channels and samples.shape[2] == config.input_channels:
            samples = samples.permute(0, 2, 1)
        expected = (config.input_channels, config.input_length)
        if tuple(samples.shape[1:]) != expected:
            raise ValueError(f'Expected [N, {expected[0]}, {expected[1]}], got {tuple(samples.shape)}')
        self.x_data = samples.contiguous()
        self.y_data = labels.contiguous()
        self.source_indices = torch.as_tensor(
            dataset.get('source_indices', torch.arange(len(labels))), dtype=torch.long
        )
        self.is_contrastive = training_mode == 'self_supervised' or training_mode.startswith('SupCon')
        if self.is_contrastive:
            self.aug1, self.aug2 = DataTransform(self.x_data, config)

    def __getitem__(self, index):
        if self.is_contrastive:
            return self.x_data[index], self.y_data[index], self.aug1[index], self.aug2[index]
        return self.x_data[index], self.y_data[index], self.x_data[index], self.x_data[index]

    def __len__(self):
        return len(self.x_data)


def ratio_from_mode(training_mode):
    match = re.search(r'_(1|5|10|50|75)p(?:$|_)', training_mode)
    return int(match.group(1)) if match else None


def resolve_train_file(data_path, training_mode, train_file=None):
    data_path = Path(data_path)
    if train_file:
        path = Path(train_file)
        return path if path.is_absolute() else data_path / path
    ratio = ratio_from_mode(training_mode)
    if training_mode.startswith('SupCon_pseudo') or training_mode.startswith('pseudo_ce'):
        if ratio is None:
            raise ValueError('Pseudo-label modes require a percentage suffix such as _5p.')
        return data_path / f'pseudo_train_{ratio}perc.pt'
    if training_mode.startswith('SupCon_labeled'):
        return data_path / f'train_{ratio}perc.pt'
    if ratio is not None and training_mode != 'self_supervised' and not training_mode.startswith('gen_pseudo'):
        return data_path / f'train_{ratio}perc.pt'
    return data_path / 'train.pt'


def data_generator(data_path, configs, training_mode, train_file=None):
    data_path = Path(data_path)
    train_path = resolve_train_file(data_path, training_mode, train_file)
    for path in [train_path, data_path / 'val.pt', data_path / 'test.pt']:
        if not path.exists():
            raise FileNotFoundError(f'Missing dataset file: {path}')
    train = Load_Dataset(safe_torch_load(train_path), configs, training_mode)
    valid = Load_Dataset(safe_torch_load(data_path / 'val.pt'), configs, training_mode)
    test = Load_Dataset(safe_torch_load(data_path / 'test.pt'), configs, training_mode)
    batch_size = min(configs.batch_size, max(2, len(train)))
    drop_last = bool(configs.drop_last and len(train) >= batch_size)
    common = dict(batch_size=batch_size, num_workers=configs.num_workers)
    return (
        DataLoader(train, shuffle=True, drop_last=drop_last, **common),
        DataLoader(valid, shuffle=False, drop_last=False, **common),
        DataLoader(test, shuffle=False, drop_last=False, **common),
    )
