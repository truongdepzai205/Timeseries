"""Aggregate metrics.json files and create report-ready tables/plots."""

from pathlib import Path
import argparse
import json
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--logs', default='experiments_logs')
    parser.add_argument('--experiment', default='SpokenArabicDigits_matrix')
    parser.add_argument('--output', default='results')
    args = parser.parse_args()
    root = Path(args.logs) / args.experiment
    rows = []
    for path in root.rglob('metrics.json'):
        row = json.loads(path.read_text(encoding='utf-8'))
        row['metrics_path'] = str(path)
        rows.append(row)
    if not rows:
        raise FileNotFoundError(f'No metrics.json found under {root}')
    output = Path(args.output); output.mkdir(parents=True, exist_ok=True)
    frame = pd.DataFrame(rows)
    if 'result_role' in frame.columns:
        frame = frame[frame['result_role'].fillna('final') == 'final'].copy()
    frame.to_csv(output / 'all_runs.csv', index=False)

    orchestration_path = root / 'orchestration_log.csv'
    if orchestration_path.exists():
        orchestration = pd.read_csv(orchestration_path)
        successful = orchestration[orchestration['status'] == 'success'].copy()
        if not successful.empty:
            successful = successful.drop_duplicates(subset=['expected_output'], keep='last')
        successful.to_csv(output / 'successful_stages.csv', index=False)
        non_shared = successful[successful['method'] != 'shared_ts'].copy()
        if not non_shared.empty:
            runtime_summary = non_shared.groupby(
                ['method', 'label_percentage', 'seed'], dropna=False, as_index=False
            )['seconds'].sum()
            runtime_summary = runtime_summary.rename(
                columns={'seconds': 'pipeline_seconds_excluding_shared_ssl'}
            )
            runtime_summary.to_csv(output / 'pipeline_runtime_by_run.csv', index=False)
        shared = successful[successful['method'] == 'shared_ts'].copy()
        if not shared.empty:
            shared[['seed', 'seconds', 'training_mode']].to_csv(
                output / 'shared_ssl_runtime.csv', index=False
            )
    numeric = ['accuracy','macro_precision','macro_recall','macro_f1','weighted_f1','cohen_kappa']
    summary = frame.groupby(['method','label_percentage'])[numeric].agg(['mean','std','count'])
    summary.to_csv(output / 'summary_by_method_and_ratio.csv')
    flat = frame.groupby(['method','label_percentage'], as_index=False)['macro_f1'].mean()
    pivot = flat.pivot(index='label_percentage', columns='method', values='macro_f1').sort_index()
    pivot.to_csv(output / 'macro_f1_pivot.csv')
    plt.figure(figsize=(10, 6))
    for method in pivot.columns:
        plt.plot(pivot.index, pivot[method], marker='o', label=method)
    plt.xlabel('Tỷ lệ nhãn (%)')
    plt.ylabel('Macro F1')
    plt.title('So sánh phương pháp theo tỷ lệ nhãn')
    plt.xticks(pivot.index)
    plt.legend()
    plt.tight_layout()
    plt.savefig(output / 'macro_f1_comparison.png', dpi=180)
    plt.close()
    print(summary)
    print(f'Saved to {output.resolve()}')


if __name__ == '__main__':
    main()
