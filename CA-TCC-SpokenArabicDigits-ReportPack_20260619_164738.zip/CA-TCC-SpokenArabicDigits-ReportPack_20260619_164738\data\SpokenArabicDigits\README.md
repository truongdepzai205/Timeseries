Run `notebooks/01_EDA_Preprocessing_SpokenArabicDigits.ipynb` first.

It creates train.pt, val.pt, test.pt and train_1perc.pt/train_5perc.pt/train_10perc.pt.
Pseudo-label files are created later by the experiment pipeline.
