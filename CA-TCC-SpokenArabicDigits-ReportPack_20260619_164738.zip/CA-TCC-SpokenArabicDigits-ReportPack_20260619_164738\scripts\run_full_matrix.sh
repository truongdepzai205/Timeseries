#!/usr/bin/env bash
set -euo pipefail
python experiments/run_experiments.py \
  --methods supervised ts_tcc ts_pl ts_supcon ca_tcc ca_scratch \
  --label_ratios 1 5 10 \
  --seeds 0 1 2 \
  --device auto
python experiments/aggregate_results.py \
  --experiment SpokenArabicDigits_matrix \
  --output results
